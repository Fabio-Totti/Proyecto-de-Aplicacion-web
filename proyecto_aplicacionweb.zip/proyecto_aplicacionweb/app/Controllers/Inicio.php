<?php

namespace App\Controllers;

class Inicio extends BaseController
{
    public function __construct(){
        helper('url');
    }
    public function index()
    {
        return view('inicio');
    }
}
