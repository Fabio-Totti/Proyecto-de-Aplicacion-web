<?php
namespace App\Controllers;

use App\Models\productosEntradaModel;
use App\Models\proveedoresModel;

class inventario extends BaseController
{
    private $productosEntradaModel;
    private $proveedoresModel;
    private $validacion;
    public function __construct()
    {
        helper('url');
        $this->productosEntradaModel = new productosEntradaModel();
        $this->proveedoresModel = new proveedoresModel();
        $this->validacion = \Config\Services::validation();
    }
    public function index()
    {
        $productos = $this->productosEntradaModel->findAll();
        $proveedores = $this->proveedoresModel->findAll();
        return view('inventario', ['productos' => $productos, 'proveedores' => $proveedores]);
    }
    public function add()
    {
        $valida = $this->validacion->getRuleGroup('producto');
        if (!$this->validate($valida)) {
            //var_dump($this->validacion->getErrors());
            session()->setFlashdata(['errores'=>$this->validacion->getErrors()]);
            return redirect()->back()->withInput();
        }
        $producto = [
            'nombre' => $this->request->getPost('nombre'),
            'descripcion' => $this->request->getPost('descripcion'),
            'existencias' => $this->request->getPost('existencias'),
            'idProveedores' => $this->request->getPost('idProveedores')
        ];

        $this->productosEntradaModel->insert($producto);

        return redirect()->to(base_url('/productos/inventario'))->with('mensaje', '1');
    }
    public function edit($id)
    {
        $id_producto = $id;
        $productos = $this->productosEntradaModel->find($id_producto);
        $proveedores = $this->proveedoresModel->findAll();
        return view('editproducto', ['productos' => $productos, 'proveedores' => $proveedores, 'id_producto' => $id_producto]);
    }

    public function update()
    {
        $valida = $this->validacion->getRuleGroup('producto');
        if (!$this->validate($valida)) {
            //var_dump($this->validacion->getErrors());
            session()->setFlashdata(['errores'=>$this->validacion->getErrors()]);
            return redirect()->back()->withInput();
        }

        $id = $this->request->getPost('idProductosEnt');
        $producto = [
            'nombre' => $this->request->getPost('nombre'),
            'descripcion' => $this->request->getPost('descripcion'),
            'existencias' => $this->request->getPost('existencias'),
            'idProveedores' => $this->request->getPost('idProveedores')
        ];

        $this->productosEntradaModel->update($id, $producto);

        return redirect()->to(base_url('/productos/inventario'))->with('mensaje', '1');
    }

    public function delete()
    {
        $id_pro = $this->request->getPost('id_pro');
        echo $id_pro;
        $this->productosEntradaModel->delete(['idProductosEnt' => $id_pro]);
        //return redirect()->to(base_url('/productos'))->with('mensaje', '1');
    }
}