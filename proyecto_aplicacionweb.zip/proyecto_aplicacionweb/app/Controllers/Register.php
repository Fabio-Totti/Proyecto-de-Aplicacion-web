<?php

namespace App\Controllers;

class Register extends BaseController
{
    public function __construct(){
        helper('url');
    }
    public function index()
    {
        return view('register');
    }
    function guardar(){
        $user = $this->request->getPost('usuario');
        $password = $this->request->getPost('password');
        $password2 = $this->request->getPost('password2');
        
        if ($password==$password2) {
            # code...
        }
    }
    
}
