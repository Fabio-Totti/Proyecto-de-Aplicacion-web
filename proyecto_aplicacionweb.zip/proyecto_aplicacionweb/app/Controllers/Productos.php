<?php

namespace App\Controllers;

class Productos extends BaseController
{
    public function __construct()
    {
        helper('url');
    }
    public function index()
    {
        return view('productos');
    }
}