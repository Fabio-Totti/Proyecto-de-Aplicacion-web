<nav class="navbar navbar-expand-lg navbar-light" style="background-color: #7E57C2;">
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo base_url() ?>inicio">
      <img src="<?php echo base_url() ?>public/imagen/Logo_navbar.png" width="140" height="60" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
      aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href="<?php echo base_url() ?>inicio">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" href="<?php echo base_url() ?>productos">Productos</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" href="<?php echo base_url() ?>proveedores">Proveedores</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" href="<?php echo base_url() ?>embarques">Embarques</a>
        </li>
      </ul>


      <ul class="nav navbar-nav navbar-right">

        <li class="nav-item">
          <div class="btn-group dropstart">
            <button type="button" class="btn btn-outline-light dropdown-toggle " data-bs-toggle="dropdown"
              aria-expanded="false">
              Hola, <?php echo session('usuario');?>
              <img src="<?php echo base_url() ?>public/imagen/user.png" width="24" height="24">
            </button>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="#">Perfil</a></li>
              <li><a class="dropdown-item" href="#">Ajustes</a></li>
              <li><a class="dropdown-item" href="<?php echo base_url('/cerrarsesion') ?>">Cerrar sesión</a></li>
            </ul>
          </div>
        </li>
        <!--
        <li class="nav-item">
          <a class="nav-link active text-white" href="">Asistencia: </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href=""><img src="<?php echo base_url() ?>public/imagen/telefono.png" width="25" height="24"> 987-654-3210</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active text-white" aria-current="page" href=""><img src="<?php echo base_url() ?>public/imagen/telefono.png" width="25" height="24"> 987-654-3211</a>
        </li>
        <li class="nav-item">
            <a class="nav-link active text-white" aria-current="page" href=""><img src="<?php echo base_url() ?>public/imagen/mail.png" title="Mail" width="25" height="24">  User@alimditrb.com.mx</a>
        </li>-->
      </ul>

    </div>
  </div>
</nav>

<main class="container" id="main">