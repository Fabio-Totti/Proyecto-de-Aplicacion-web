</main>

<script src="<?php echo base_url() ?>public/js/jquery.min.js"></script>
<script src="<?php echo base_url() ?>/public/js/popper.min.js"></script>
<script src="<?php echo base_url() ?>public/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url() ?>/public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() ?>/public/js/bootstrap.js"></script>

<div class="container pt-5">
    <img src="<?php echo base_url() ?>public/imagen/Logo.png" class="rounded mx-auto d-block" width="40" height="40"
        alt="">
    <p class="text-center">Copyright© 2023 Alimentos distribuidos, S.A. de C.V.
        </br>Politica de privacidad</p>
</div>

</body>
</html>