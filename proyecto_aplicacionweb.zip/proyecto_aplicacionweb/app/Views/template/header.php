<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>
		<?php
			echo (isset($titulo)) ? $titulo : 'APP';
		?>
	</title>
    <link href="<?php echo base_url() ?>public/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<main>