<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Registrarse</title>
    <link href="<?php echo base_url() ?>public/css/bootstrap.min.css" rel="stylesheet">
    
</head>

<body>
    </br>
    </br>
    <div class="container pt-5">

        <div class="text-center">
            <img src="<?php echo base_url() ?>public/imagen/Logo3.png" class="rounded" alt="">
        </div>
        </br>
        </br>
        <div class="card mx-auto" style="width: 35%;">
            <div class="card-header text-white bg-primary">
                <h4>Registrarse</h4>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo base_url() ?>register_users">

                    <div class="mb-3">
                        <label for="usuario">Ingresa tu nombre de usuario:</label>
                        <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Ejemplo: admin" required="">
                    </div>
                    </br>
                    <div class="mb-3">
                        <label for="password">Ingresa tu contraseña:</label>
                        <input type="password" class="form-control" id="password" name="password" placeholder="*****" minlength="5" required="">
                    </div>
                    </br>
                    <div class="mb-3">
                        <label for="password2">Repite tu contraseña:</label>
                        <input type="password" class="form-control" id="password2" name="password2" placeholder="*****" minlength="5" required="">
                    </div>
                    </br>
                    <button type="submit" class="btn btn-primary">Registrar</button>
                    <a href="<?php echo base_url() ?>login" class="btn btn-link">Volver</a>
                </form>
            </div>
        </div>
    </div>
    </br>
    </br>
    </br>

    <script src="<?php echo base_url() ?>public/js/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>public/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url() ?>/public/js/popper.min.js"></script>
    <script src="<?php echo base_url() ?>/public/js/bootstrap.min.js"></script>
</body>

<footer>
    <div class="container pt-5">
        <img src="<?php echo base_url() ?>public/imagen/Logo.png" class="rounded mx-auto d-block" width="40" height="40" alt="">
        <p class="text-center">Copyright© 2023 Alimentos distribuidos, S.A. de C.V.
            </br>Politica de privacidad</p>
    </div>
</footer>

</html>