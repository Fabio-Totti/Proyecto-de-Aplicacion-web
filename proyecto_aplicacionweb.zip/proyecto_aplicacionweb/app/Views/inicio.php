<?php
$titulo = "Inicio";
include_once('template/header.php');
include_once('template/Navbar.php');
?>
</br>
<div class="p-2 mb-4 bg-light rounded-3">
	<div class="container-fluid py-5">
		<h1 class="display-5 fw-bold text-center">Bienvendido. Elija una opción</h1>
		<p class=" fs-4 text-center">Recuerde que siempre puede explorar estas funciones desde las opciones generales de
			la barra de tareas.</p>
	</div>
</div>

<div class="card container g-3 align-items-center">
	<div class="row gy-2 gx-3 p-3 align-items-center">
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option1.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Ver inventario</h5>
							<p class="card-text">Registra, elimina o actualiza detalles de materias primas requeridas.
							</p>
							<p class="card-text"><small class="text-muted">Productos</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option2.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Lista de proveedores</h5>
							<p class="card-text">Ingresa o actualiza la información de tus proveedores.
							</p>
							<p class="card-text"><small class="text-muted">Proveedores</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option3.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Crea embarque</h5>
							<p class="card-text">Registra el envio de productos a un cliente especifico.
							</p>
							<p class="card-text"><small class="text-muted">Embarques</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option4.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Lista de clientes</h5>
							<p class="card-text">Registra, elimina o actualiza detalles de los clientes directos.
							</p>
							<p class="card-text"><small class="text-muted">Embarques</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option5.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Bitácora de productos</h5>
							<p class="card-text">Genera la bitácora de productos elaborados en un determinado tiempo.
							</p>
							<p class="card-text"><small class="text-muted">Productos</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option6.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Reporte de emparque</h5>
							<p class="card-text">Encuentra todos los reportes de embarques generados.
							</p>
							<p class="card-text"><small class="text-muted">Embarques</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>

<?php
include_once('template/footer.php');
?>