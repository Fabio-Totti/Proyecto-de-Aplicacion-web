
<script>
    base_url = "<?php echo base_url() ?>productos/delete";
</script>


<?php
$titulo = "Inventario";
include_once('template/header.php');
include_once('template/Navbar.php');
?>

</br>
</br>
<a href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addProducto">Agregar Producto</a>
</br>
</br>
<?php if (session('errores')):
        $errores = session('errores'); ?>
        <div class="alert alert-danger" role="alert" >
            <?php foreach ($errores as $e): ?>
                <div class="text-danger">
                    <?= $e ?>
                </div>
            <?php endforeach; ?>
        </div>
<?php endif; ?>
<!-- Modal add -->
<form action="<?php echo base_url() ?>add" method="post" enctype="multipart/form-data">

    <div class="modal fade" id="addProducto" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">

        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Agregar Producto</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" id="nombre" name="nombre"
                            placeholder="Ejemplo: Bebida, lata, ..." required="">
                    </div>
                    <div class="form-group">
                        <label for="descripcion">Descripción:</label>
                        <textarea class="form-control" id="descripcion" name="descripcion"
                            placeholder="Ejemplo: Bebida, lata, ..." required="" id="exampleFormControlTextarea1"
                            rows="2"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="existencias">Existencias:</label>
                        <input type="number" class="form-control" id="existencias" name="existencias" placeholder="0"
                            required="">
                    </div>
                    <div class="form-group">
                        <label for="idProveedores">Proveedor:</label>
                        <div class="col-10">
                            <select name="idProveedores" id="idProveedores" class="form-control">
                                <?php foreach ($proveedores as $c): ?>
                                    <option value="<?= $c->idProveedores ?>"><?= $c->nombre ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <button type="submit" class="btn btn-primary">Guardar</button>
                </div>
            </div>
        </div>
    </div>
</form>

<br />
<h3 align="center">Lista de productos</h3>

</br>

<table class="table  table-striped-columns">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Descripción</th>
            <th>Existencias</th>
            <th>Proveedor</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($productos as $p): ?>
            <tr>
                <td><?= $p->idProductosEnt ?></td>
                <td><?= $p->nombre ?></td>
                <td><?= $p->descripcion ?></td>
                <td><?= $p->existencias ?></td>
                <?php foreach ($proveedores as $c): ?>
                    <?php if ($c->idProveedores === $p->idProveedores): ?>
                        <td><?= $c->nombre ?></td>
                    <?php endif; ?>
                <?php endforeach ?>
                <td>
                    <a href="<?php echo base_url() ?>productos/editproducto/<?= $p->idProductosEnt ?>" class='btn btn-warning'>Editar</a> | <a
                        id="deletebutton" href="<?php echo base_url() ?>productos/inventario" data-id_pro="<?= $p->idProductosEnt ?>" class='btn btn-danger'>Eliminar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="<?=base_url('/public/js/auth/delete.js')?>"></script>

<?php
include_once('template/footer.php');
?>