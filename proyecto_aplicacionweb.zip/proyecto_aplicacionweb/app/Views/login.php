<?php
$titulo = "Login";
include_once('template/header.php');
?>

</br>
</br>
<div class="container pt-5">

    <div class="text-center">
        <img src="<?php echo base_url() ?>public/imagen/Logo3.png" class="rounded" alt="">
    </div>
    </br>
    </br>
    <div class="card mx-auto" style="width: 35%;">
        <div class="card-header text-white bg-primary">
            <h4>Login</h4>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo base_url('/login') ?>">
                <div class="mb-3">
                    <label for="usuario">Usuario:</label>
                    <input type="text" class="form-control" id="usuario" name="usuario" placeholder="Ejemplo: admin"
                        required="">
                </div>

                <div class="mb-3">
                    <label for="password">Contraseña:</label>
                    <input type="password" class="form-control" id="password" name="password" placeholder="*****"
                        minlength="3" required="">
                </div>
                </br>
                <button type="submit" class="btn btn-primary">Ingresar</button>
                <!--<a href="<?php echo base_url() ?>register" class="btn btn-link">Registrarse</a>-->
            </form>
        </div>
    </div>
</div>
</br>
</br>
</br>
</br>

<?php
	include_once('template/footer.php');
?>