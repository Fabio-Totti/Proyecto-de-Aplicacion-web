<!--
<script>
    base_url = "<?php echo base_url() ?>productos/update";
</script>
-->
<?php
$titulo = "Editar producto";
include_once('template/header.php');
include_once('template/Navbar.php');
?>
</br>
</br>



<div class="card container g-3 p-4" style="max-width: 550px;">
    <?php if (session('errores')):
        $errores = session('errores'); ?>
        <div class="card">
            <?php foreach ($errores as $e): ?>
                <div class="text-danger">
                    <?= $e ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    </br>

    <form action="<?php echo base_url() ?>productos/update" method="post" enctype="multipart/form-data" 
    id="formupdate">

        <h4 class="text-center">Editar Producto</h4>

        <div class="form-group p-2">
            <input type="hidden" class="form-control" id="idProductosEnt" name="idProductosEnt"
                value="<?php echo $productos->idProductosEnt ?>">
        </div>
        <div class="form-group p-2">
            <label for="nombre">Nombre:</label>
            <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Ejemplo: Bebida, lata, ..."
                required="" value="<?php echo $productos->nombre ?>">
        </div>
        <div class="form-group p-2">
            <label for="descripcion">Descripción:</label>
            <textarea class="form-control" id="descripcion" name="descripcion" placeholder="Ejemplo: Bebida, lata, ..."
                required="" id="exampleFormControlTextarea1" rows="2"><?php echo $productos->descripcion ?></textarea>
        </div>
        <div class="form-group p-2">
            <label for="existencias">Existencias:</label>
            <input type="number" class="form-control" id="existencias" name="existencias" placeholder="0" required=""
                value="<?php echo $productos->existencias ?>">
        </div>
        <div class="form-group p-2">
            <label for="idProveedores">Proveedor:</label>
            <select name="idProveedores" id="idProveedores" class="form-control"
                value="<?php echo $productos->idProveedores ?>">
                <?php foreach ($proveedores as $c): ?>
                    <option value="<?= $c->idProveedores ?>"><?= $c->nombre ?></option>
                <?php endforeach ?>
            </select>
        </div>

        </br>
        <div class="form-group p-2">
            <a type="button" class="btn btn-secondary" href="<?php echo base_url() ?>productos/inventario">Regresar</a>
            <button type="submit" class="btn btn-primary" data-idproducto="<?php echo $productos->idProductosEnt ?>">Actualizar</button>
        </div>

    </form>
</div>

<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="<?=base_url('/public/js/auth/update.js')?>"></script>
                -->
<?php
include_once('template/footer.php');
?>