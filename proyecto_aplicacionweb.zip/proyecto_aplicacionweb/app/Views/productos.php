<?php
$titulo = "Productos";
include_once('template/header.php');
include_once('template/Navbar.php');
?>
</br>
</br>
<div class="p-1 mb-4 bg-light rounded-3">
	<div class="container-fluid py-5">
		<h2 class="display-5 fw-bold text-center">Menu de productos. Elija una opción</h2>
	</div>
</div>
</br>
<div class="card container g-3 align-items-center" style="max-width: 875px;">
	<div class="row gy-2 gx-3 p-3 align-items-center">
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<a class="col-md-5" style="width: auto; margin: auto auto;" href="<?php echo base_url() ?>productos/inventario">
						<img src="<?php echo base_url() ?>public/imagen/option1.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</a>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Ver inventario</h5>
							<p class="card-text">Registra, elimina o actualiza detalles de materias primas requeridas.
							</p>
							<p class="card-text"><small class="text-muted">Productos</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="col-auto">
			<div class="card mb-3" style="max-width: 400px;">
				<div class="row g-0">
					<div class="col-md-5" style="width: auto; margin: auto auto;">
						<img src="<?php echo base_url() ?>public/imagen/option5.png"
							class="img-fluid rounded-start pt-2" width="150" height="150" alt="">
					</div>
					<div class="col-md-7">
						<div class="card-body">
							<h5 class="card-title">Bitácora de productos</h5>
							<p class="card-text">Genera la bitácora de productos elaborados en un determinado tiempo.
							</p>
							<p class="card-text"><small class="text-muted">Productos</small></p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php
include_once('template/footer.php');
?>