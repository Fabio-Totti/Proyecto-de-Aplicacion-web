<?php
namespace App\Models;

use CodeIgniter\Model;

class proveedoresModel extends Model{
    protected $primaryKey = 'idProveedores';
    protected $table = 'proveedores';
    protected $returnType = 'object';//object array
    protected $allowedFields = ['nombre','direccion','ciudad','codigo_postal','estado','telefono','correo_electronico'];
}