<?php namespace App\Models;
    use CodeIgniter\Model;
    
    class productosEntradaModel extends Model{
        protected $primaryKey = 'idProductosEnt';
        protected $table = 'productos_entrada';
        protected $returnType = 'object';// object array
        protected $allowedFields = ['nombre', 'descripcion', 'existencias', 'idProveedores'];
    }