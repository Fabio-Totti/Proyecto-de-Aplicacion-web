<?php
define("PRODUCTO", [
    'nombre' => [
        'rules' => 'required|max_length[50]',
        'errors' => [
            'required' => 'El campo nombre es requerido',
            'max_length' => 'El nombre introducido excede la cantidad de caracteres soportada'
        ]
    ],
    'descripcion' => [
        'rules' => 'required|max_length[150]',
        'errors' => [
            'required' => 'El campo nombre es requerido',
            'max_length' => 'La descripcion introducida excede la cantidad de caracteres soportada'
        ]
    ],
    'existencias' => [
        'rules' => 'required|numeric',
        'errors' => [
            'required' => 'El campo existencias es requerido',
            'numeric' => 'El campo existencias solo acepta numeros enteros'
        ]
    ],
    'idProveedores' => [
        'rules' => 'required|numeric',
        'errors' => [
            'required' => 'El campo proveedores es requerido',
            'numeric' => 'El campo proveedores solo acepta numeros enteros'
        ]
    ],
]);