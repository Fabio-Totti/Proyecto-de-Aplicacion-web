<?php
	session_start();
	
	define('APP_PATH',$_SERVER['DOCUMENT_ROOT'] . '/progweb/');
	define('BASE_URL','http://localhost/progweb/');
	
	define('HOST','localhost');
	define('USER','root');
	define('PASSWORD','Mynfer2343tui');
	define('BD','tienda');
	
	define('ADMIN',1);
	define('CLIENTE',2);

	define("UPLOAD",APP_PATH . 'upload/');
	//cargando funciones
	include_once( APP_PATH . 'include/conexion.php' );
	include_once( APP_PATH . 'include/funciones.php' );

	
?>