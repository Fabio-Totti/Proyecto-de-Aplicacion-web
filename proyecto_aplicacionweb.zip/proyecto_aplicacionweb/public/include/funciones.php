<?php
	
	function upload($file,$ruta){
		$nombre = rand() . '-'.$_FILES[$file]['name'];
		$ruta .= $nombre;// $ruta = $ruta . $nombre;
		if (move_uploaded_file($_FILES[$file]['tmp_name'], $ruta))
			return $nombre;
		else
			return ""; 

	}

	function sesion($tipo = ADMIN){
		@$us = $_SESSION['login'];

		if(!empty($us)){
			if($us->tipo != ADMIN)
				redirect(BASE_URL . 'index.php');
				
		}else
			redirect( BASE_URL . 'login.php');
	}

	function mensaje($msj,$estilo){
		echo "<div class='alert $estilo alert-dismissible fade show' role='alert'>
			  $msj
			  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
			    <span aria-hidden='true'>&times;</span>
			  </button>
			</div>";

	}

	function flash_session(){
		if(isset($_SESSION['msj'])){
			$msj = $_SESSION['msj'];
			mensajes($msj['mensaje'],$msj['class']);
			unset($_SESSION['msj']);
		}
	}

	function redirect($direccion){
		echo "<script> document.location.href='$direccion'; </script>";
	}

	function validaSesion($tipo = "admin"){
		if(!isset($_SESSION['login'])){
			redirect(BASE_URL . 'login.php');
		}
		$us = $_SESSION['login'];

		if($us->tipo == 2 && $tipo == "admin")
			redirect(BASE_URL . 'cliente');	
		

	}