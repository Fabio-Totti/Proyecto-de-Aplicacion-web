$(document).ready(function() {

    console.log("Dentro");
    $('#send').click(function() {
        var id = $(this).data('id');
        console.log(id);
        $.ajax({
          type: 'POST',
          url: base_url + 'productos/update',
          data: {
            id: id, 
          },
          success: function(response) {
            // Manejar la respuesta del servidor
          },
          error: function(xhr, status, error) {
            // Manejar errores
          }
        });
      });
});