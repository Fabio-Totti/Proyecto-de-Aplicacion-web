(function($) {
    $('#deletebutton').click(function() {
      var id_pro = $(this).data('id_pro');
      
      $.ajax({
        type: 'POST',
        url: base_url,
        data: {
            id_pro: id_pro
        },
        success: function(response) {
          // Manejar la respuesta del servidor
        },
        error: function(xhr, status, error) {
          // Manejar errores
        }
      });
    });
})(jQuery)