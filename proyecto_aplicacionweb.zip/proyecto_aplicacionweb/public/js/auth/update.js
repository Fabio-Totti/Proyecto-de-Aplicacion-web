(function($) {
    $("#formupdate").submit(function(ev){
        ev.preventDefault();
        var idproducto = $(this).data('idproducto');
        console.log(idproducto);
        $.ajax({
            url: base_url,
            type: 'POST',
            data: $(this).serialize(),
            success: function() {
                // Manejar la respuesta del servidor
            },
            error: function() {
                // Manejar errores
            },
        });
    });
    
})(jQuery)